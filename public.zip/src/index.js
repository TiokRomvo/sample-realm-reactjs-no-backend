import React from 'react';
import ReactDOM from 'react-dom';
import ShareVideos from "./ShareVideos";

ReactDOM.render(<React.StrictMode>
  <ShareVideos/>
</React.StrictMode>, document.getElementById('root'));
